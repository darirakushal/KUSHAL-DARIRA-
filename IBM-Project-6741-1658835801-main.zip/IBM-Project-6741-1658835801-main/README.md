# IBM-Project-6741-1658835801
### SmartFarmer - IOT Enabled Smart Farming Application
Dataset Link - darirakushal

# Team ID
```
PNT2022TMID39877
```

# Team Members

```
1. KUSHAL DARIRA R (TL) - 511319104038 

2. HARI KRISHNA D       - 511319104020

3. BALAJI R             - 511319104009

4. KAMESH C             - 511319104031
```

# Faculty Mentor

```
SAMUNDEESWARI M
```

# Assignments

- [x] 1. Build a Arduino Code using 3 Sensors , 1 Buzzer And LED :tada:

- [x] 2. Build a python code, Assume u get temperature and humidity values (generated with random function to a variable) and write a 
         condition to continuously detect alarm in case of high temperature :tada:
         
- [x] 3. Write python code for blinking LED and Traffic lights for Raspberry pi. :tada:

- [x] 4. Write code and connections in wokwi for the ultrasonic sensor.
Whenever the distance is less than 100 cms send an "alert" to the IBM cloud and display in
the device recent events.
Upload document with wokwi share link and images of IBM cloud :tada:

**Assignment Folder -https://github.com/IBM-EPBL/IBM-Project-6741-1658835801/tree/main/Assignment**

# Final Deliverables

**https://github.com/IBM-EPBL/IBM-Project-6741-1658835801/tree/main/Final%20Deliverables**

# Video Demo Link

**https://onedrive.live.com/?authkey=%21AD3Nc3f%5FZKfemUw&cid=3355E34A8E536C36&id=3355E34A8E536C36%211632&parId=3355E34A8E536C36%211631&o=OneUp**
