import random
flag=0
temp=random.randint(1, 100)
humid=random.randint(1, 100)
if(temp>50):
        print("temprature,humidity:",temp,humid)
else:
        print("High temprature",temp,humid)
flag=1
