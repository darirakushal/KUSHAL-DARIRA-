from gpiozero import LED, Button
from time import sleep

red = LED(18)
amber = LED(2)
green = LED(17)
button = Button(3)

print("Press the button when you want to cross.")

green.on()
amber.off()
red.off()

while True:
    print("Wait")
    button.wait_for_press()
    green.off()
    amber.on()
    sleep(5)
    amber.off()
    red.on()
    print("Cross now.")
    sleep(10)
    amber.on()
    sleep(5)
    green.on()
    amber.off()
    red.off()
