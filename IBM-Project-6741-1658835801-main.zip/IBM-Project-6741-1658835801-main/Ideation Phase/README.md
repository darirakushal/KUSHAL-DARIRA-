**EMPATHY MAP : https://app.mural.co/invitation/mural/smartfarmingiot7063/1662389862761?sender=u201482dccc61fc21b94c2025&key=e1183e01-9cd2-4097-ae72-304b69a4da15**

**Brain Storm : https://app.mural.co/invitation/mural/smartfarmingiot7063/1663348792796?sender=u201482dccc61fc21b94c2025&key=312ba23c-f7ae-4dd3-9570-e1538e583233**
